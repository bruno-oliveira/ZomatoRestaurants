var app = angular.module('app',  []);

app.controller('RestaurantCtrl', function($scope,$http) {
	alert("Teste");
	$scope.removeCirc=function(){
		circle.setMap(null);
	}
});

angular.bootstrap(document.getElementById('search'), ["app"]);
